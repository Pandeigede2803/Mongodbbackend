// const {validationResult} = require('express-validator')
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("../models/user");

exports.signup = (req, res, next) => {
  const email = req.body.email;
  const name = req.body.name;
  const ps = req.body.password;

  console.log(req.body);

  bcrypt.hash(ps, 8, function (err, hash) {
    if (err) {
      console.log(err);
    }

    const newUser = new User({
      email: email,
      password: hash,
      name: name,
    });
    newUser.save().then((result) => {
      res.json({
        message: "User sukses registrasi",
        userId: result._id,
        password: result.password,
      });
    });
  });
};

exports.login = (req, res, next) => {
  const emailP = req.body.email;
  const pswd = req.body.password;

  let loggedUser;
  //mencari user yg sedang login
  User.findOne({ email: emailP })
    .then((userFound) => {
      if (!userFound) {
        const error = new Error("User dengan email tersebut tidak ditemukan");
        error.statusCode = 433;
        throw error;
      }

      loggedUser = userFound;

      return bcrypt.compare(pswd, loggedUser.password);
    })
    .then((isEqual) => {
      if (!isEqual) {
        const error = new Error("Password salah");
        error.statusCode = 424;
        throw error;
      }

      const token = jwt.sign(
        {
          email: loggedUser.email,
          userId: loggedUser._id.toString(),
        },
        "myprivate54321",
        { expiresIn: "1h" }
      );

      res.json({ jwttoken: token, userId: loggedUser._id.toString() });
    })
    .catch((err) => console.log(err));
};